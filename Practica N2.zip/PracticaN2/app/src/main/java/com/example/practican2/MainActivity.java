package com.example.practican2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
    EditText txtNombre;
    EditText txtApellido;
    EditText txtEdad;

    TextView txtGenerado;

    RadioGroup rgrupo;
    RadioButton rbtnHombre;
    RadioButton rbtnMujer;

    Button btnGenerador;
    Button btnLimpiar;

    Switch switchHijos;
    boolean hijos;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Instanciar
        txtNombre = (EditText)findViewById(R.id.txtNombre);
        txtApellido = (EditText)findViewById(R.id.txtApellido);
        txtEdad = (EditText)findViewById(R.id.txtEdad);
        txtGenerado = (TextView)findViewById(R.id.txtGenerado);

        rgrupo = (RadioGroup)findViewById(R.id.radioGroup);
        rbtnHombre = (RadioButton)findViewById(R.id.rbtnHombre);
        rbtnMujer = (RadioButton)findViewById(R.id.rbtnMujer);

        btnGenerador = (Button)findViewById(R.id.btnGenerar);
        btnLimpiar = (Button)findViewById(R.id.btnLimpiar);

        switchHijos = (Switch)findViewById(R.id.switchHijos);

        final Spinner spn1;
        ArrayAdapter adaptadorDeArrayDeFichero;

        spn1 = (Spinner)findViewById(R.id.listaEstados);
        adaptadorDeArrayDeFichero = ArrayAdapter.createFromResource(this, R.array.estadoCivil, R.layout.support_simple_spinner_dropdown_item);
        spn1.setAdapter(adaptadorDeArrayDeFichero);


        //LISTENER BOTÓN GENERAR.
        btnGenerador.setOnClickListener(new Button.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                String nombre = "";
                String apellido = "";
                String radioSeleccion = "";
                String estadoCivil = "";

                //int pos = spn1.getSelectedItemPosition();

                //Cojer valor string de opcion spinner seleccionada
                estadoCivil = spn1.getSelectedItem().toString();




                boolean checked = eleccionGenero(rbtnHombre, rbtnMujer);


                //Comprobar si algun campo esta vacio
                if (txtNombre.getText().toString().isEmpty() || txtNombre.equals("") || txtNombre.length() == 0)
                {
                    txtGenerado.setText("[FALTA NOMBRE]");
                    txtGenerado.setTextColor(getResources().getColor(R.color.rojo, null));
                }
                else if (txtApellido.getText().toString().isEmpty() || txtApellido.equals("") || txtApellido.length() == 0)
                {
                    txtGenerado.setText("[FALTA APELLIDO]");
                    txtGenerado.setTextColor(getResources().getColor(R.color.rojo, null));
                }
                else if (checked == false)
                {
                    txtGenerado.setText("[FALTA GENERO]");
                    txtGenerado.setTextColor(getResources().getColor(R.color.rojo, null));
                }
                else if (spn1.getSelectedItem().toString().equals("ESTADO CIVIL"))
                {
                    txtGenerado.setText("[FALTA ESTADO CIVIL]");
                    txtGenerado.setTextColor(getResources().getColor(R.color.rojo, null));
                }
                else if (txtEdad.getText().toString().isEmpty() || txtEdad.equals("") || txtEdad.length() == 0)
                {
                    txtGenerado.setText("[FALTA EDAD]");
                    txtGenerado.setTextColor(getResources().getColor(R.color.rojo, null));
                }


                //Si no hay nada vacio, comprobar la edad y si tiene hijos
                try
                {
                    boolean hijos = hijosSiNo(switchHijos);
                    int miEdad = Integer.parseInt(txtEdad.getText().toString());
                    nombre = txtNombre.getText().toString();
                    apellido = txtApellido.getText().toString();

                    if (miEdad >= 18)
                    {
                        if (hijos == true)
                        {
                            txtGenerado.setText(apellido + ", " + nombre + ", mayor de edad, " + radioSeleccion + " " + estadoCivil + " y con hijos");
                            txtGenerado.setTextColor(getResources().getColor(R.color.negro, null));
                        }
                        else
                        {
                            txtGenerado.setText(apellido + ", " + nombre + ", mayor de edad, " + radioSeleccion + " " + estadoCivil + " y sin hijos");
                            txtGenerado.setTextColor(getResources().getColor(R.color.negro, null));
                        }
                    }

                    else if (miEdad < 18)
                    {
                        if (hijos == true)
                        {
                            txtGenerado.setText(apellido + ", " + nombre + ", menor de edad, " + radioSeleccion + " " + estadoCivil + " y con hijos");
                            txtGenerado.setTextColor(getResources().getColor(R.color.negro, null));
                        }
                        else
                        {
                            txtGenerado.setText(apellido + ", " + nombre + ", menor de edad, " + radioSeleccion + " " + estadoCivil + " y sin hijos");
                            txtGenerado.setTextColor(getResources().getColor(R.color.negro, null));
                        }
                    }
                }
                catch (NumberFormatException nfe)
                {
                }
            }
        });


        //Listener Boton Limpiar
        btnLimpiar.setOnClickListener(new Button.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                txtNombre.setText("");
                txtApellido.setText("");
                txtEdad.setText("");
                rgrupo.clearCheck();
                spn1.setSelection(0);
                switchHijos.setChecked(false);
                txtGenerado.setText("");
            }
        });
    }



    //MÉTODO OBTENER SI HA ESCOGIDO GÉNERO
    public boolean eleccionGenero(RadioButton rbtnHombre, RadioButton rbtnMujer){

        boolean checked = false;

        if (rbtnHombre.isChecked())
        {
            checked = true;
        }
        else if (rbtnMujer.isChecked())
        {
            checked = true;
        }

        return checked;
    }


    //MÉTODO PARA SABER SI TIENE HIJOS O NO
    public boolean hijosSiNo(Switch switchHijos)
    {

        boolean checked = false;

        if (switchHijos.isChecked())
        {
            checked = true;
        }

        return checked;
    }
}